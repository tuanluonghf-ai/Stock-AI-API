"""Deprecated UI narrative utilities.

UI narrative generation is disabled; renderers must consume narrative packs only.
"""
