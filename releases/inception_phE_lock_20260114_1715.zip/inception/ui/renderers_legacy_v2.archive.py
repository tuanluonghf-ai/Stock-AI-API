"""Archived legacy renderer.

This module is intentionally inert to prevent UI-side narrative generation.
"""
