"""Deprecated communication layer.

Narrative generation is disabled in UI; keep logic in core packs only.
"""
